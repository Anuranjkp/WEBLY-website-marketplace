<?php
//about theme info
add_action( 'admin_menu', 'vw_minimalist_gettingstarted' );
function vw_minimalist_gettingstarted() {    	
	add_theme_page( esc_html__('About VW Minimalist', 'vw-minimalist'), esc_html__('About VW Minimalist', 'vw-minimalist'), 'edit_theme_options', 'vw_minimalist_guide', 'vw_minimalist_mostrar_guide');   
}

// Add a Custom CSS file to WP Admin Area
function vw_minimalist_admin_theme_style() {
   wp_enqueue_style('vw-minimalist-custom-admin-style', esc_url(get_template_directory_uri()) . '/inc/getstart/getstart.css');
   wp_enqueue_script('vw-minimalist-tabs', esc_url(get_template_directory_uri()) . '/inc/getstart/js/tab.js');
   wp_enqueue_style( 'font-awesome-css', esc_url(get_template_directory_uri()).'/assets/css/fontawesome-all.css' );
}
add_action('admin_enqueue_scripts', 'vw_minimalist_admin_theme_style');

//guidline for about theme
function vw_minimalist_mostrar_guide() { 
	//custom function about theme customizer
	$return = add_query_arg( array()) ;
	$theme = wp_get_theme( 'vw-minimalist' );
?>

<div class="wrapper-info">
    <div class="col-left">
    	<h2><?php esc_html_e( 'Welcome to VW Minimalist Theme', 'vw-minimalist' ); ?> <span class="version">Version: <?php echo esc_html($theme['Version']);?></span></h2>
    	<p><?php esc_html_e('All our WordPress themes are modern, minimalist, 100% responsive, seo-friendly,feature-rich, and multipurpose that best suit designers, bloggers and other professionals who are working in the creative fields.','vw-minimalist'); ?></p>
    </div>
    <div class="col-right">
    	<div class="logo">
			<img src="<?php echo esc_url(get_template_directory_uri()); ?>/inc/getstart/images/final-logo.png" alt="" />
		</div>
		<div class="update-now">
			<h4><?php esc_html_e('Buy VW Minimalist at 20% Discount','vw-minimalist'); ?></h4>
			<h4><?php esc_html_e('Use Coupon','vw-minimalist'); ?> ( <span><?php esc_html_e('vwpro20','vw-minimalist'); ?></span> ) </h4> 
			<div class="info-link">
				<a href="<?php echo esc_url( VW_MINIMALIST_BUY_NOW ); ?>" target="_blank"> <?php esc_html_e( 'Upgrade to Pro', 'vw-minimalist' ); ?></a>
			</div>
		</div>
    </div>

    <div class="tab-sec">
		<div class="tab">
			<button class="tablinks" onclick="vw_minimalist_open_tab(event, 'lite_theme')"><?php esc_html_e( 'Setup With Customizer', 'vw-minimalist' ); ?></button>
			<button class="tablinks" onclick="vw_minimalist_open_tab(event, 'block_pattern')"><?php esc_html_e( 'Setup With Block Pattern', 'vw-minimalist' ); ?></button>
			<button class="tablinks" onclick="vw_minimalist_open_tab(event, 'gutenberg_editor')"><?php esc_html_e( 'Setup With Gutunberg Block', 'vw-minimalist' ); ?></button>	
			<button class="tablinks" onclick="vw_minimalist_open_tab(event, 'product_addons_editor')"><?php esc_html_e( 'Woocommerce Product Addons', 'vw-minimalist' ); ?></button>
		  	<button class="tablinks" onclick="vw_minimalist_open_tab(event, 'minimalist_pro')"><?php esc_html_e( 'Get Premium', 'vw-minimalist' ); ?></button>
		  	<button class="tablinks" onclick="vw_minimalist_open_tab(event, 'free_pro')"><?php esc_html_e( 'Support', 'vw-minimalist' ); ?></button>
		</div>

		<!-- Tab content -->
		<?php
			$vw_minimalist_plugin_custom_css = '';
			if(class_exists('Ibtana_Visual_Editor_Menu_Class')){
				$vw_minimalist_plugin_custom_css ='display: block';
			}
		?>
		<div id="lite_theme" class="tabcontent open">
			<?php if(!class_exists('Ibtana_Visual_Editor_Menu_Class')){ 
				$plugin_ins = VW_Minimalist_Plugin_Activation_Settings::get_instance();
				$vw_minimalist_actions = $plugin_ins->recommended_actions;
				?>
				<div class="vw-minimalist-recommended-plugins">
				    <div class="vw-minimalist-action-list">
				        <?php if ($vw_minimalist_actions): foreach ($vw_minimalist_actions as $key => $vw_minimalist_actionValue): ?>
				                <div class="vw-minimalist-action" id="<?php echo esc_attr($vw_minimalist_actionValue['id']);?>">
			                        <div class="action-inner">
			                            <h3 class="action-title"><?php echo esc_html($vw_minimalist_actionValue['title']); ?></h3>
			                            <div class="action-desc"><?php echo esc_html($vw_minimalist_actionValue['desc']); ?></div>
			                            <?php echo wp_kses_post($vw_minimalist_actionValue['link']); ?>
			                            <a class="ibtana-skip-btn" get-start-tab-id="lite-theme-tab" href="javascript:void(0);"><?php esc_html_e('Skip','vw-minimalist'); ?></a>
			                        </div>
				                </div>
				            <?php endforeach;
				        endif; ?>
				    </div>
				</div>
			<?php } ?>
			<div class="lite-theme-tab" style="<?php echo esc_attr($vw_minimalist_plugin_custom_css); ?>">
				<h3><?php esc_html_e( 'Lite Theme Information', 'vw-minimalist' ); ?></h3>
				<hr class="h3hr">
			  	<p><?php esc_html_e('Free Minimalist WordPress Theme is a simple, sleek, classy and spacious theme that not just focuses on the design. It considers the content of your website as an important parameter for spreading the word about your services and business. Minimalist design is not a new concept. However, there is an ongoing trend of such themes and many businesses prefer them to obtain the maximum benefit. This theme; being a minimal one, will provide you with a beautiful layout that puts forward your content in a stylish way. The minimalist design of this theme is helpful in delivering great performance and good user-experience that is seldom seen in most of the free themes. Its responsive nature will make your website scalable and look fantastic on various handheld devices such as tablets and smart phones along with laptops and desktops. With this free theme, you dont need to go the extra mile for getting a website ready.','vw-minimalist'); ?></p>
			  	<div class="col-left-inner">
			  		<h4><?php esc_html_e( 'Theme Documentation', 'vw-minimalist' ); ?></h4>
					<p><?php esc_html_e( 'If you need any assistance regarding setting up and configuring the Theme, our documentation is there.', 'vw-minimalist' ); ?></p>
					<div class="info-link">
						<a href="<?php echo esc_url( VW_MINIMALIST_FREE_THEME_DOC ); ?>" target="_blank"> <?php esc_html_e( 'Documentation', 'vw-minimalist' ); ?></a>
					</div>
					<hr>
					<h4><?php esc_html_e('Theme Customizer', 'vw-minimalist'); ?></h4>
					<p> <?php esc_html_e('To begin customizing your website, start by clicking "Customize".', 'vw-minimalist'); ?></p>
					<div class="info-link">
						<a target="_blank" href="<?php echo esc_url( admin_url('customize.php') ); ?>"><?php esc_html_e('Customizing', 'vw-minimalist'); ?></a>
					</div>
					<hr>				
					<h4><?php esc_html_e('Having Trouble, Need Support?', 'vw-minimalist'); ?></h4>
					<p> <?php esc_html_e('Our dedicated team is well prepared to help you out in case of queries and doubts regarding our theme.', 'vw-minimalist'); ?></p>
					<div class="info-link">
						<a href="<?php echo esc_url( VW_MINIMALIST_SUPPORT ); ?>" target="_blank"><?php esc_html_e('Support Forum', 'vw-minimalist'); ?></a>
					</div>
					<hr>
					<h4><?php esc_html_e('Reviews & Testimonials', 'vw-minimalist'); ?></h4>
					<p> <?php esc_html_e('All the features and aspects of this WordPress Theme are phenomenal. I\'d recommend this theme to all.', 'vw-minimalist'); ?>  </p>
					<div class="info-link">
						<a href="<?php echo esc_url( VW_MINIMALIST_REVIEW ); ?>" target="_blank"><?php esc_html_e('Reviews', 'vw-minimalist'); ?></a>
					</div>
			  		<div class="link-customizer">
						<h3><?php esc_html_e( 'Link to customizer', 'vw-minimalist' ); ?></h3>
						<hr class="h3hr">
						<div class="first-row">
							<div class="row-box">
								<div class="row-box1">
									<span class="dashicons dashicons-buddicons-buddypress-logo"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[control]=custom_logo') ); ?>" target="_blank"><?php esc_html_e('Upload your logo','vw-minimalist'); ?></a>
								</div>
								<div class="row-box2">
									<span class="dashicons dashicons-slides"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_slidersettings') ); ?>" target="_blank"><?php esc_html_e('Slider Settings','vw-minimalist'); ?></a>
								</div>
							</div>
							<div class="row-box">
								<div class="row-box1">
									<span class="dashicons dashicons-admin-customizer"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_global_typography') ); ?>" target="_blank"><?php esc_html_e('Typography','vw-minimalist'); ?></a>
								</div>
								<div class="row-box2">
									<span class="dashicons dashicons-editor-table"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_services') ); ?>" target="_blank"><?php esc_html_e('Services Section','vw-minimalist'); ?></a>
								</div>
							</div>
							<div class="row-box">
								<div class="row-box1">
									<span class="dashicons dashicons-menu"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[panel]=nav_menus') ); ?>" target="_blank"><?php esc_html_e('Menus','vw-minimalist'); ?></a>
								</div>
								<div class="row-box2">
									<span class="dashicons dashicons-screenoptions"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[panel]=widgets') ); ?>" target="_blank"><?php esc_html_e('Footer Widget','vw-minimalist'); ?></a>
								</div>
							</div>

							<div class="row-box">
								<div class="row-box1">
									<span class="dashicons dashicons-format-gallery"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_post_settings') ); ?>" target="_blank"><?php esc_html_e('Post settings','vw-minimalist'); ?></a>
								</div>
								 <div class="row-box2">
									<span class="dashicons dashicons-align-center"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_woocommerce_section') ); ?>" target="_blank"><?php esc_html_e('WooCommerce Layout','vw-minimalist'); ?></a>
								</div> 
							</div>
							
							<div class="row-box">
								<div class="row-box1">
									<span class="dashicons dashicons-admin-generic"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_left_right') ); ?>" target="_blank"><?php esc_html_e('General Settings','vw-minimalist'); ?></a>
								</div>
								<div class="row-box2">
									<span class="dashicons dashicons-text-page"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_footer') ); ?>" target="_blank"><?php esc_html_e('Footer Text','vw-minimalist'); ?></a>
								</div>
							</div>
						</div>
					</div>
			  	</div>
				<div class="col-right-inner">
					<h3 class="page-template"><?php esc_html_e('How to set up Home Page Template','vw-minimalist'); ?></h3>
				  	<hr class="h3hr">
					<p><?php esc_html_e('Follow these instructions to setup Home page.','vw-minimalist'); ?></p>
	                <ul>
	                  	<p><span class="strong"><?php esc_html_e('1. Create a new page :','vw-minimalist'); ?></span><?php esc_html_e(' Go to ','vw-minimalist'); ?>
					  	<b><?php esc_html_e(' Dashboard >> Pages >> Add New Page','vw-minimalist'); ?></b></p>

	                  	<p><?php esc_html_e('Name it as "Home" then select the template "Custom Home Page".','vw-minimalist'); ?></p>
	                  	<img src="<?php echo esc_url(get_template_directory_uri()); ?>/inc/getstart/images/home-page-template.png" alt="" />
	                  	<p><span class="strong"><?php esc_html_e('2. Set the front page:','vw-minimalist'); ?></span><?php esc_html_e(' Go to ','vw-minimalist'); ?>
					  	<b><?php esc_html_e(' Settings >> Reading ','vw-minimalist'); ?></b></p>
					  	<p><?php esc_html_e('Select the option of Static Page, now select the page you created to be the homepage, while another page to be your default page.','vw-minimalist'); ?></p>
	                  	<img src="<?php echo esc_url(get_template_directory_uri()); ?>/inc/getstart/images/set-front-page.png" alt="" />
	                  	<p><?php esc_html_e(' Once you are done with this, then follow the','vw-minimalist'); ?> <a class="doc-links" href="https://www.vwthemesdemo.com/docs/free-vw-minimalist/" target="_blank"><?php esc_html_e('Documentation','vw-minimalist'); ?></a></p>
	                </ul>
			  	</div>
			</div>
		</div>

		<div id="block_pattern" class="tabcontent">
			<?php if(!class_exists('Ibtana_Visual_Editor_Menu_Class')){ 
			$plugin_ins = VW_Minimalist_Plugin_Activation_Settings::get_instance();
			$vw_minimalist_actions = $plugin_ins->recommended_actions;
			?>
				<div class="vw-minimalist-recommended-plugins">
				    <div class="vw-minimalist-action-list">
				        <?php if ($vw_minimalist_actions): foreach ($vw_minimalist_actions as $key => $vw_minimalist_actionValue): ?>
				                <div class="vw-minimalist-action" id="<?php echo esc_attr($vw_minimalist_actionValue['id']);?>">
			                        <div class="action-inner">
			                            <h3 class="action-title"><?php echo esc_html($vw_minimalist_actionValue['title']); ?></h3>
			                            <div class="action-desc"><?php echo esc_html($vw_minimalist_actionValue['desc']); ?></div>
			                            <?php echo wp_kses_post($vw_minimalist_actionValue['link']); ?>
			                            <a class="ibtana-skip-btn" href="javascript:void(0);" get-start-tab-id="gutenberg-editor-tab"><?php esc_html_e('Skip','vw-minimalist'); ?></a>
			                        </div>
				                </div>
				            <?php endforeach;
				        endif; ?>
				    </div>
				</div>
			<?php } ?>
			<div class="gutenberg-editor-tab" style="<?php echo esc_attr($vw_minimalist_plugin_custom_css); ?>">
				<div class="block-pattern-img">
				  	<h3><?php esc_html_e( 'Block Patterns', 'vw-minimalist' ); ?></h3>
					<hr class="h3hr">
					<p><?php esc_html_e('Follow the below instructions to setup Home page with Block Patterns.','vw-minimalist'); ?></p>
	              	<p><b><?php esc_html_e('Click on Below Add new page button >> Click on "+" Icon >> Click Pattern Tab >> Click on homepage sections >> Publish.','vw-minimalist'); ?></span></b></p>
	              	<div class="vw-minimalist-pattern-page">
				    	<a href="javascript:void(0)" class="vw-pattern-page-btn button-primary button"><?php esc_html_e('Add New Page','vw-minimalist'); ?></a>
				    </div>
	              	<img src="<?php echo esc_url(get_template_directory_uri()); ?>/inc/getstart/images/block-pattern.png" alt="" />	
	            </div>

	            <div class="block-pattern-link-customizer">
	              	<div class="link-customizer-with-block-pattern">
							<h3><?php esc_html_e( 'Link to customizer', 'vw-minimalist' ); ?></h3>
							<hr class="h3hr">
							<div class="first-row">
								<div class="row-box">
									<div class="row-box1">
										<span class="dashicons dashicons-buddicons-buddypress-logo"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[control]=custom_logo') ); ?>" target="_blank"><?php esc_html_e('Upload your logo','vw-minimalist'); ?></a>
									</div>
									<div class="row-box2">
										<span class="dashicons dashicons-networking"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_social_icon_settings') ); ?>" target="_blank"><?php esc_html_e('Social Icons','vw-minimalist'); ?></a>
									</div>
								</div>
								<div class="row-box">
									<div class="row-box1">
										<span class="dashicons dashicons-menu"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[panel]=nav_menus') ); ?>" target="_blank"><?php esc_html_e('Menus','vw-minimalist'); ?></a>
									</div>
									
									<div class="row-box2">
										<span class="dashicons dashicons-text-page"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_footer') ); ?>" target="_blank"><?php esc_html_e('Footer Text','vw-minimalist'); ?></a>
									</div>
								</div>

								<div class="row-box">
									<div class="row-box1">
										<span class="dashicons dashicons-format-gallery"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_post_settings') ); ?>" target="_blank"><?php esc_html_e('Post settings','vw-minimalist'); ?></a>
									</div>
									 <div class="row-box2">
										<span class="dashicons dashicons-align-center"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_woocommerce_section') ); ?>" target="_blank"><?php esc_html_e('WooCommerce Layout','vw-minimalist'); ?></a>
									</div> 
								</div>
								
								<div class="row-box">
									<div class="row-box1">
										<span class="dashicons dashicons-admin-generic"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_left_right') ); ?>" target="_blank"><?php esc_html_e('General Settings','vw-minimalist'); ?></a>
									</div>
									 <div class="row-box2">
										<span class="dashicons dashicons-screenoptions"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[panel]=widgets') ); ?>" target="_blank"><?php esc_html_e('Footer Widget','vw-minimalist'); ?></a>
									</div> 
								</div>
							</div>
					</div>	
				</div>
	        </div>
		</div>

		<div id="gutenberg_editor" class="tabcontent">
			<?php if(!class_exists('Ibtana_Visual_Editor_Menu_Class')){ 
			$plugin_ins = VW_Minimalist_Plugin_Activation_Settings::get_instance();
			$vw_minimalist_actions = $plugin_ins->recommended_actions;
			?>
				<div class="vw-minimalist-recommended-plugins">
				    <div class="vw-minimalist-action-list">
				        <?php if ($vw_minimalist_actions): foreach ($vw_minimalist_actions as $key => $vw_minimalist_actionValue): ?>
				                <div class="vw-minimalist-action" id="<?php echo esc_attr($vw_minimalist_actionValue['id']);?>">
			                        <div class="action-inner plugin-activation-redirect">
			                            <h3 class="action-title"><?php echo esc_html($vw_minimalist_actionValue['title']); ?></h3>
			                            <div class="action-desc"><?php echo esc_html($vw_minimalist_actionValue['desc']); ?></div>
			                            <?php echo wp_kses_post($vw_minimalist_actionValue['link']); ?>
			                        </div>
				                </div>
				            <?php endforeach;
				        endif; ?>
				    </div>
				</div>
			<?php }else{ ?>
				<h3><?php esc_html_e( 'Gutunberg Blocks', 'vw-minimalist' ); ?></h3>
				<hr class="h3hr">
				<div class="vw-minimalist-pattern-page">
			    	<a href="<?php echo esc_url( admin_url( 'admin.php?page=ibtana-visual-editor-templates' ) ); ?>" class="vw-pattern-page-btn ibtana-dashboard-page-btn button-primary button"><?php esc_html_e('Ibtana Settings','vw-minimalist'); ?></a>
			    </div>

			    <div class="link-customizer-with-guternberg-ibtana">
					<h3><?php esc_html_e( 'Link to customizer', 'vw-minimalist' ); ?></h3>
					<hr class="h3hr">
					<div class="first-row">
						<div class="row-box">
							<div class="row-box1">
								<span class="dashicons dashicons-buddicons-buddypress-logo"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[control]=custom_logo') ); ?>" target="_blank"><?php esc_html_e('Upload your logo','vw-minimalist'); ?></a>
							</div>
							<div class="row-box2">
								<span class="dashicons dashicons-networking"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_social_icon_settings') ); ?>" target="_blank"><?php esc_html_e('Social Icons','vw-minimalist'); ?></a>
							</div>
						</div>
						<div class="row-box">
							<div class="row-box1">
								<span class="dashicons dashicons-menu"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[panel]=nav_menus') ); ?>" target="_blank"><?php esc_html_e('Menus','vw-minimalist'); ?></a>
							</div>
							
							<div class="row-box2">
								<span class="dashicons dashicons-text-page"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_footer') ); ?>" target="_blank"><?php esc_html_e('Footer Text','vw-minimalist'); ?></a>
							</div>
						</div>

						<div class="row-box">
							<div class="row-box1">
								<span class="dashicons dashicons-format-gallery"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_post_settings') ); ?>" target="_blank"><?php esc_html_e('Post settings','vw-minimalist'); ?></a>
							</div>
							 <div class="row-box2">
								<span class="dashicons dashicons-align-center"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_woocommerce_section') ); ?>" target="_blank"><?php esc_html_e('WooCommerce Layout','vw-minimalist'); ?></a>
							</div> 
						</div>
						
						<div class="row-box">
							<div class="row-box1">
								<span class="dashicons dashicons-admin-generic"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[section]=vw_minimalist_left_right') ); ?>" target="_blank"><?php esc_html_e('General Settings','vw-minimalist'); ?></a>
							</div>
							 <div class="row-box2">
								<span class="dashicons dashicons-screenoptions"></span><a href="<?php echo esc_url( admin_url('customize.php?autofocus[panel]=widgets') ); ?>" target="_blank"><?php esc_html_e('Footer Widget','vw-minimalist'); ?></a>
							</div> 
						</div>
					</div>
				</div>
			<?php } ?>
		</div>

		<div id="product_addons_editor" class="tabcontent product_woo_tab">
			<?php if(!is_plugin_active('ibtana-ecommerce-product-addons/plugin.php')){ 
				$plugin_ins = VW_Minimalist_Plugin_Activation_Woo_Products::get_instance();
				$vw_minimalist_actions = $plugin_ins->recommended_actions;
				?>
				<div class="vw-minimalist-recommended-plugins">
			    	<div class="vw-minimalist-action-list">
                	<div class="vw-minimalist-action" id="<?php echo esc_attr($vw_minimalist_actions['id']);?>">
                     <div class="action-inner plugin-activation-redirect">
                        <h3 class="action-title"><?php echo esc_html($vw_minimalist_actions['title']); ?></h3>
                        <div class="action-desc"><?php echo esc_html($vw_minimalist_actions['desc']); ?>
                        </div>
                        <?php echo wp_kses_post($vw_minimalist_actions['link']); ?>
                     </div>
                	</div>
			    	</div>
				</div>
			<?php }else{ ?>
				<h3><?php esc_html_e( 'Woocommerce Products Blocks', 'vw-minimalist' ); ?></h3>
				<hr class="h3hr">
           	<div class="vw-minimalist-pattern-page">
		    		<a href="<?php echo esc_url( admin_url( 'admin.php?page=ibtana-visual-editor-templates&woo=true' ) ); ?>" class="vw-pattern-page-btn ibtana-dashboard-page-btn button-primary button"><?php esc_html_e('Woocommerce Templates','vw-minimalist'); ?></a>
		    	</div>
			<?php } ?>
		</div>

		<div id="minimalist_pro" class="tabcontent">
		  	<h3><?php esc_html_e( 'Premium Theme Information', 'vw-minimalist' ); ?></h3>
			<hr class="h3hr">
		    <div class="col-left-pro">
		    	<p><?php esc_html_e('This Minimalist WordPress Theme is a powerful theme with the flexibility to suit any business type. It has been crafted by the developers with the utmost attention. Their painstaking efforts have resulted in a beautiful theme that gives attention to details. It is a complete package for minimal style websites. The best thing about a minimalist theme is that it allows your content to get noticed without getting overshadowed by the fancy design elements of the theme. It pleasantly surprises you with the operating speed and its minimal loading time thus keeping your visitors intact. The design of WP Minimalist WordPress Theme is very clean and has no tacky elements that may seem unnecessary. Its multi-conceptual layout works magnificently for blogs, magazines, corporate offices, industries, agencies, or other fields. With this magnificently crafted theme, you can be quick on your feet as it is very easy to install, set-up and use.','vw-minimalist'); ?></p>
		    	<div class="pro-links">
			    	<a href="<?php echo esc_url( VW_MINIMALIST_LIVE_DEMO ); ?>" target="_blank"><?php esc_html_e('Live Demo', 'vw-minimalist'); ?></a>
					<a href="<?php echo esc_url( VW_MINIMALIST_BUY_NOW ); ?>" target="_blank"><?php esc_html_e('Buy Pro', 'vw-minimalist'); ?></a>
					<a href="<?php echo esc_url( VW_MINIMALIST_PRO_DOC ); ?>" target="_blank"><?php esc_html_e('Pro Documentation', 'vw-minimalist'); ?></a>
				</div>
		    </div>
		    <div class="col-right-pro">
		    	<img src="<?php echo esc_url(get_template_directory_uri()); ?>/inc/getstart/images/responsive.png" alt="" />
		    </div>
		    <div class="featurebox">
			    <h3><?php esc_html_e( 'Theme Features', 'vw-minimalist' ); ?></h3>
				<hr class="h3hr">
				<div class="table-image">
					<table class="tablebox">
						<thead>
							<tr>
								<th></th>
								<th><?php esc_html_e('Free Themes', 'vw-minimalist'); ?></th>
								<th><?php esc_html_e('Premium Themes', 'vw-minimalist'); ?></th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td><?php esc_html_e('Theme Customization', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Responsive Design', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Logo Upload', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Social Media Links', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Slider Settings', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Number of Slides', 'vw-minimalist'); ?></td>
								<td class="table-img"><?php esc_html_e('4', 'vw-minimalist'); ?></td>
								<td class="table-img"><?php esc_html_e('Unlimited', 'vw-minimalist'); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Template Pages', 'vw-minimalist'); ?></td>
								<td class="table-img"><?php esc_html_e('3', 'vw-minimalist'); ?></td>
								<td class="table-img"><?php esc_html_e('6', 'vw-minimalist'); ?></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Home Page Template', 'vw-minimalist'); ?></td>
								<td class="table-img"><?php esc_html_e('1', 'vw-minimalist'); ?></td>
								<td class="table-img"><?php esc_html_e('1', 'vw-minimalist'); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Theme sections', 'vw-minimalist'); ?></td>
								<td class="table-img"><?php esc_html_e('2', 'vw-minimalist'); ?></td>
								<td class="table-img"><?php esc_html_e('10', 'vw-minimalist'); ?></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Contact us Page Template', 'vw-minimalist'); ?></td>
								<td class="table-img">0</td>
								<td class="table-img"><?php esc_html_e('1', 'vw-minimalist'); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Blog Templates & Layout', 'vw-minimalist'); ?></td>
								<td class="table-img">0</td>
								<td class="table-img"><?php esc_html_e('3(Full width/Left/Right Sidebar)', 'vw-minimalist'); ?></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Page Templates & Layout', 'vw-minimalist'); ?></td>
								<td class="table-img">0</td>
								<td class="table-img"><?php esc_html_e('2(Left/Right Sidebar)', 'vw-minimalist'); ?></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Color Pallete For Particular Sections', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Global Color Option', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Section Reordering', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Demo Importer', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Allow To Set Site Title, Tagline, Logo', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Enable Disable Options On All Sections, Logo', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Full Documentation', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Latest WordPress Compatibility', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Woo-Commerce Compatibility', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Support 3rd Party Plugins', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Secure and Optimized Code', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Exclusive Functionalities', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Section Enable / Disable', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Section Google Font Choices', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Gallery', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Simple & Mega Menu Option', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Support to add custom CSS / JS ', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Shortcodes', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Custom Background, Colors, Header, Logo & Menu', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Premium Membership', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Budget Friendly Value', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('Priority Error Fixing', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Custom Feature Addition', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr class="odd">
								<td><?php esc_html_e('All Access Theme Pass', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td><?php esc_html_e('Seamless Customer Support', 'vw-minimalist'); ?></td>
								<td class="table-img"><i class="fas fa-times"></i></td>
								<td class="table-img"><i class="fas fa-check"></i></td>
							</tr>
							<tr>
								<td></td>
								<td class="table-img"></td>
								<td class="update-link"><a href="<?php echo esc_url( VW_MINIMALIST_BUY_NOW ); ?>" target="_blank"><?php esc_html_e('Upgrade to Pro', 'vw-minimalist'); ?></a></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>

		<div id="free_pro" class="tabcontent">
		  	<div class="col-3">
		  		<h4><span class="dashicons dashicons-star-filled"></span><?php esc_html_e('Pro Version', 'vw-minimalist'); ?></h4>
				<p> <?php esc_html_e('To gain access to extra theme options and more interesting features, upgrade to pro version.', 'vw-minimalist'); ?></p>
				<div class="info-link">
					<a href="<?php echo esc_url( VW_MINIMALIST_BUY_NOW ); ?>" target="_blank"><?php esc_html_e('Get Pro', 'vw-minimalist'); ?></a>
				</div>
		  	</div>
		  	<div class="col-3">
		  		<h4><span class="dashicons dashicons-cart"></span><?php esc_html_e('Pre-purchase Queries', 'vw-minimalist'); ?></h4>
				<p> <?php esc_html_e('If you have any pre-sale query, we are prepared to resolve it.', 'vw-minimalist'); ?></p>
				<div class="info-link">
					<a href="<?php echo esc_url( VW_MINIMALIST_CONTACT ); ?>" target="_blank"><?php esc_html_e('Question', 'vw-minimalist'); ?></a>
				</div>
		  	</div>
		  	<div class="col-3">		  		
		  		<h4><span class="dashicons dashicons-admin-customizer"></span><?php esc_html_e('Child Theme', 'vw-minimalist'); ?></h4>
				<p> <?php esc_html_e('For theme file customizations, make modifications in the child theme and not in the main theme file.', 'vw-minimalist'); ?></p>
				<div class="info-link">
					<a href="<?php echo esc_url( VW_MINIMALIST_CHILD_THEME ); ?>" target="_blank"><?php esc_html_e('About Child Theme', 'vw-minimalist'); ?></a>
				</div>
		  	</div>

		  	<div class="col-3">
		  		<h4><span class="dashicons dashicons-admin-comments"></span><?php esc_html_e('Frequently Asked Questions', 'vw-minimalist'); ?></h4>
				<p> <?php esc_html_e('We have gathered top most, frequently asked questions and answered them for your easy understanding. We will list down more as we get new challenging queries. Check back often.', 'vw-minimalist'); ?></p>
				<div class="info-link">
					<a href="<?php echo esc_url( VW_MINIMALIST_FAQ ); ?>" target="_blank"><?php esc_html_e('View FAQ','vw-minimalist'); ?></a>
				</div>
		  	</div>

		  	<div class="col-3">
		  		<h4><span class="dashicons dashicons-sos"></span><?php esc_html_e('Support Queries', 'vw-minimalist'); ?></h4>
				<p> <?php esc_html_e('If you have any queries after purchase, you can contact us. We are eveready to help you out.', 'vw-minimalist'); ?></p>
				<div class="info-link">
					<a href="<?php echo esc_url( VW_MINIMALIST_SUPPORT ); ?>" target="_blank"><?php esc_html_e('Contact Us', 'vw-minimalist'); ?></a>
				</div>
		  	</div>
		</div>
	</div>
</div>
<?php } ?>